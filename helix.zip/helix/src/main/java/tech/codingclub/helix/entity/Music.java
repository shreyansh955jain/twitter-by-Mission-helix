package tech.codingclub.helix.entity;
public class Music {

    public String album;
    public String Child_link;
    public String duration;
    public String lyricist;
    public  String music_director;
    public String parent_link;
    public String singers;

}
