package tech.codingclub.helix.entity;

/**
 * Created by hackme on 8/7/18.
 */
public class MemberBase {
    public Long id;
}
