 var counter=2;
 setInterval (  function() { counter++; doucment.title= counter +"notifications" },1000);